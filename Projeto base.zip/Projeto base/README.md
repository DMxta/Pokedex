# Desafio DIO Pokedex

Desafio: Criar uma Pokedex baseado em um design do site Dribbble de Saepul Nahwan. Adaptando o design para mobile e browser.

Link para visualização/navegação: https://dmxta.github.io/Pokedex/

Feito com:
 - HTML
 - CSS
 - JavaScript
 
 IDE:
  - VS Code

Resultado:

MOBILE

![image](https://github.com/DMxta/Pokedex/assets/136941005/cd89357d-a3e8-4b2a-a94c-94ffc3a0ccab)



BROWSER

![image](https://github.com/DMxta/Pokedex/assets/136941005/e861deb1-9b78-4147-bd1b-1c9fadb4886a)
